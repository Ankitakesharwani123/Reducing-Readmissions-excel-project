"""
Step 2 - Answer the 10 basic-level case-study questions with pandas / scipy.

Input : data/processed/HA_Data_clean.csv
Output: reports/basic_questions_results.md

Run   : python scripts/02_eda_basic_questions.py
"""
from pathlib import Path
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "processed" / "HA_Data_clean.csv")
raw = pd.read_csv(ROOT / "data" / "raw" / "HA_Data.csv", usecols=["weight", "readmitted"]).drop_duplicates()
R = "readmitted"
out = []


def md(t: pd.DataFrame, fmt=None) -> str:
    # object dtype keeps integer columns as integers (no "77.000") and lets us show gaps as "-"
    t = t.astype(object).where(t.notna(), "-")
    return t.to_markdown(floatfmt=fmt or ".3f")


def add(title, body):
    out.append(f"## {title}\n\n{body}\n")


def corr(a, b="readmitted"):
    r, p = stats.pearsonr(df[a], df[b])
    return f"Pearson r = **{r:.3f}** (p = {p:.1e}, n = {len(df):,})"


overall = df[R].mean()
out.append(f"# Basic-level questions - results\n\nBase: **{len(df):,}** unique encounters, overall 30-day readmission rate **{overall:.1%}**.\n")

# Q1 age
t = df.groupby("age_group")[R].agg(encounters="size", readmit_rate="mean")
add("Q1. Readmission rate by age group", md(t) +
    f"\n\nHighest: **{t.readmit_rate.idxmax()}** ({t.readmit_rate.max():.1%}); lowest: **{t.readmit_rate.idxmin()}** ({t.readmit_rate.min():.1%}, only {t.loc[t.readmit_rate.idxmin(), 'encounters']:,} encounters). "
    "Rates climb gradually from about 42% (30s) to about 48% (70s-80s); the 90s dip and the under-10 group are small samples.")

# Q2 LOS by specialty
known = df[df.medical_specialty != "Unknown"]
t = known.groupby("medical_specialty").agg(encounters=(R, "size"), avg_los=("time_in_hospital", "mean"), readmit_rate=(R, "mean"))
t = t[t.encounters >= 100].sort_values("avg_los", ascending=False)
add("Q2. Average length of stay by specialty (known specialties with 100+ encounters)",
    md(pd.concat([t.head(5), t.tail(5)])) +
    f"\n\nLongest: **{t.index[0]}** ({t.avg_los.iloc[0]:.1f} days). Shortest: **{t.index[-1]}** ({t.avg_los.iloc[-1]:.1f} days). "
    f"{(df.medical_specialty == 'Unknown').mean():.0%} of encounters have no specialty recorded.")

# Q3 emergency visits
t = df.groupby("prior_er_band")[R].agg(encounters="size", readmit_rate="mean")
add("Q3. Prior emergency visits vs readmission", corr("number_emergency") + "\n\n" + md(t) +
    f"\n\nWeak linear correlation, but the banded view shows a clear step-up: 3+ prior ER visits is {t.readmit_rate.iloc[-1] / t.readmit_rate.iloc[0]:.1f}x the rate of 0 visits.")

# Q4 diabetes
yes = df[df.diabetesMed == "Yes"]
dx250 = df[df[["diag_1", "diag_2", "diag_3", "diag_4"]].astype(str).apply(lambda c: c.str.startswith("250")).any(axis=1)]
add("Q4. Share of diabetic patients readmitted within 30 days",
    f"- Using `diabetesMed = Yes`: **{yes[R].mean():.1%}** of {len(yes):,} encounters (vs {df[df.diabetesMed == 'No'][R].mean():.1%} for `No`).\n"
    f"- Using ICD-9 codes starting `250` in diag_1..diag_4: **{dx250[R].mean():.1%}** of {len(dx250):,} encounters.")

# Q5 medication change
ct = pd.crosstab(df.medication_change, df[R])
chi, p, *_ = stats.chi2_contingency(ct)
t = df.groupby("medication_change")[R].agg(encounters="size", readmit_rate="mean")
add("Q5. Diabetic medication change vs readmission", md(t) +
    f"\n\nChi-square = {chi:.1f}, p = {p:.1e} -> difference is statistically significant (+{(t.readmit_rate['Changed'] - t.readmit_rate['No Change']) * 100:.1f} pts when the regimen was changed). "
    "Association only: patients whose medication is changed may already be sicker.")

# Q6 lab procedures
t = df.groupby("lab_band")[R].agg(encounters="size", readmit_rate="mean")
add("Q6. Lab procedures vs readmission", corr("num_lab_procedures") + "\n\n" + md(t) +
    "\n\nVery weak relationship (rate rises from 42.8% to 49.4% up to 80 labs, then falls in a tiny group).")

# Q7 race x gender
mf = df[df.gender.isin(["Female", "Male"])]          # 2 'Unknown' gender rows are left out here
t = mf.pivot_table(index="race", columns="gender", values=R, aggfunc="mean")
n = mf.pivot_table(index="race", columns="gender", values=R, aggfunc="size")
g = mf.groupby("gender")[R].mean()
add("Q7. Readmission rate by race and gender (2 rows with unknown gender excluded)",
    md(t) + "\n\nEncounters:\n\n" + md(n, ".0f") +
    f"\n\nOverall: female {g['Female']:.1%} vs male {g['Male']:.1%}. Caucasian ({t.mean(axis=1)['Caucasian']:.1%}) and African-American "
    f"({t.mean(axis=1)['AfricanAmerican']:.1%}) patients are highest; Asian, Hispanic, Other and Unknown have small samples (300-1,100 encounters). "
    "Gaps may reflect how data was recorded rather than differences in care - investigate before acting.")

# Q8 weight
known_w = df[df.weight != "Unknown"]
t = known_w.groupby("weight")[R].agg(encounters="size", readmit_rate="mean")
add("Q8. Weight categories vs readmission",
    f"`weight` is recorded for only **{len(known_w) / len(df):.1%}** of encounters ({len(known_w):,} rows) - too sparse for reliable conclusions.\n\n" + md(t))

# Q9 medications vs LOS
r, p = stats.pearsonr(df.num_medications, df.time_in_hospital)
slope = stats.linregress(df.num_medications, df.time_in_hospital).slope
t = df.groupby("medication_band").time_in_hospital.agg(encounters="size", avg_los="mean")
add("Q9. Number of medications vs length of stay",
    f"Pearson r = **{r:.3f}**; each extra medication is associated with ~**{slope:.2f} extra days** of stay.\n\n" + md(t))

# Q10 outpatient
t = df.assign(band=pd.cut(df.number_outpatient, [-1, 0, 1, 2, 999], labels=["0", "1", "2", "3+"])).groupby("band", observed=True)[R].agg(encounters="size", readmit_rate="mean")
add("Q10. Prior outpatient visits vs readmission", corr("number_outpatient") + "\n\n" + md(t) +
    "\n\nAny prior outpatient visit is associated with a higher rate (~58-60% vs ~44% with none), but there is no further gradient beyond 1 visit.")

# bonus: comorbidity (medium Q2) and the strongest predictors
t = df.groupby("comorbidity_band").agg(encounters=(R, "size"), avg_los=("time_in_hospital", "mean"), readmit_rate=(R, "mean"))
add("Bonus (medium Q2). Comorbidity (number of diagnoses)", md(t))

num = ["number_inpatient", "number_emergency", "number_diagnoses", "number_outpatient", "num_medications", "time_in_hospital", "num_lab_procedures", "num_procedures"]
c = df[num + [R]].corr()[R].drop(R).sort_values(ascending=False)
add("Bonus. Correlation of each numeric field with readmission", md(c.to_frame("pearson_r")) +
    "\n\nPrior inpatient visits is the strongest single signal, followed by prior ER visits and number of diagnoses.")

(ROOT / "reports" / "basic_questions_results.md").write_text("\n".join(out), encoding="utf-8")
print("wrote reports/basic_questions_results.md")
