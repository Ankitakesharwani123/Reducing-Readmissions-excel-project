"""
Step 1 - Clean the raw hospital readmission data.

Input : data/raw/HA_Data.csv
Output: data/processed/HA_Data_clean.csv   (analysis-ready data, one row per unique encounter)
        reports/data_quality_log.md          (what was found / what was changed)

Run   : python scripts/01_clean_data.py
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "HA_Data.csv"
OUT = ROOT / "data" / "processed" / "HA_Data_clean.csv"
LOG = ROOT / "reports" / "data_quality_log.md"

df = pd.read_csv(RAW)
n_raw = len(df)

# ---- 1. exact duplicate rows -------------------------------------------------
n_dupe = int(df.duplicated().sum())
df = df.drop_duplicates().reset_index(drop=True)

# ---- 2. missing-value markers ('?') -> 'Unknown' ------------------------------
missing_report = {c: int((df[c] == "?").sum()) for c in ["race", "weight", "medical_specialty"]}
for c in ["race", "weight", "medical_specialty"]:
    df[c] = df[c].replace("?", "Unknown")
df["gender"] = df["gender"].replace("Unknown/Invalid", "Unknown")

# ---- 3. friendlier labels -------------------------------------------------------
# '[70-80)' means 70-79 -> '70-79 yrs'.  (Labels deliberately cannot be parsed as a
# number/date, because Excel's COUNTIFS would otherwise coerce a criterion like "10-20".)
def age_label(a: str) -> str:
    lo = int(a.strip("[)").split("-")[0])
    return f"{lo}-{lo + 9} yrs"

df["age_group"] = df["age"].map(age_label)
df["medication_change"] = df["change"].map({"Ch": "Changed", "No": "No Change"})

# ---- 4. derived bands used by the dashboard --------------------------------------
def band(s, edges, labels):
    return pd.cut(s, bins=edges, labels=labels, right=True).astype(str)

df["prior_inpatient_band"] = band(df["number_inpatient"], [-1, 0, 1, 2, 3, 999],
                                  ["0 visits", "1 visit", "2 visits", "3 visits", "4+ visits"])
df["prior_er_band"] = band(df["number_emergency"], [-1, 0, 1, 2, 999],
                           ["0 visits", "1 visit", "2 visits", "3+ visits"])
df["comorbidity_band"] = band(df["number_diagnoses"], [-1, 4, 6, 8, 999],
                              ["1-4 dx", "5-6 dx", "7-8 dx", "9+ dx"])
df["medication_band"] = band(df["num_medications"], [-1, 10, 15, 20, 30, 999],
                             ["1-10 meds", "11-15 meds", "16-20 meds", "21-30 meds", "31+ meds"])
df["lab_band"] = band(df["num_lab_procedures"], [-1, 20, 40, 60, 80, 999],
                      ["0-20 labs", "21-40 labs", "41-60 labs", "61-80 labs", "81+ labs"])

df.to_csv(OUT, index=False)

# ---- 5. data quality log -----------------------------------------------------------
lines = [
    "# Data quality log",
    "",
    f"- Raw rows: **{n_raw:,}**",
    f"- Exact duplicate rows removed: **{n_dupe:,}** ({n_dupe / n_raw:.1%}) -> **{len(df):,}** unique encounters remain",
    f"- Unique patients after de-duplication: **{df.patient_id.nunique():,}**",
    f"- `encounter_id` is unique after de-duplication: **{df.encounter_id.is_unique}**",
    "",
    "## Missing / invalid values (after de-duplication)",
    "",
    "| Column | Rows marked `?` | Share | Treatment |",
    "|---|---|---|---|",
]
for c, v in missing_report.items():
    lines.append(f"| {c} | {v:,} | {v / len(df):.1%} | recoded to `Unknown` |")
lines += [
    f"| gender | {(df.gender == 'Unknown').sum()} | <0.01% | `Unknown/Invalid` recoded to `Unknown` |",
    f"| X1, X2 | {int(df[['X1','X2']].isna().sum().sum()):,} blank cells | - | left as-is (not used in the dashboard) |",
    "",
    "## Things to know before interpreting results",
    "",
    f"- **Readmission rate is high**: {df.readmitted.mean():.1%} of encounters are flagged `readmitted = 1`. "
    "Public diabetes-readmission data usually shows ~10-12% for <30 days, so treat this file as a training/case-study dataset, not real hospital performance.",
    f"- **`weight` is {missing_report['weight'] / len(df):.0%} missing**, so weight-based analysis is not reliable.",
    f"- **`medical_specialty` is {missing_report['medical_specialty'] / len(df):.0%} unknown**; specialty charts only show known specialties.",
    "- **No date column exists**, so the 'trend / seasonality' question in the case study cannot be answered with this file.",
    "- No discharge-disposition, cost, or satisfaction fields exist, so those case-study questions are out of scope.",
    "- `diag_5` is a continuous float, not a diagnosis code - it is not used.",
    "",
    "## Derived columns added",
    "",
    "`age_group`, `medication_change`, `prior_inpatient_band`, `prior_er_band`, `comorbidity_band`, `medication_band`, `lab_band`.",
]
LOG.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"raw={n_raw:,}  duplicates removed={n_dupe:,}  clean={len(df):,}")
