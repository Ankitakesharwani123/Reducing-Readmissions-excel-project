"""
Step 3 - Build the Excel dashboard (Hospital_Readmission_Dashboard.xlsx).

Input : data/processed/HA_Data_clean.csv   (created by 01_clean_data.py)
Output: dashboard/Hospital_Readmission_Dashboard.xlsx

Workbook design
  Dashboard : filters (dropdowns) -> KPI cards -> auto-updating insights -> 9 charts
  About     : purpose, how to use, definitions, assumptions
  Calc      : every number the Dashboard shows is a live COUNTIFS / SUMIFS formula here
  Data      : the cleaned encounter-level data (48,911 rows) - formulas read from this sheet

Run   : python scripts/03_build_dashboard.py
Options (mostly for maintainers):
  --out PATH        output file
  --cache PATH      an already-calculated copy of the workbook; its values are stored as the
                    formulas' cached results so previews (and Python readers) show numbers
                    before Excel recalculates
  --shot            hide Calc/Data/About so the file exports to a one-page Dashboard PDF
  --preset "Gender=Female,Race=Caucasian"   pre-select filter values (used for screenshots)
"""
import argparse
from pathlib import Path

import pandas as pd
import xlsxwriter

ROOT = Path(__file__).resolve().parents[1]

ap = argparse.ArgumentParser()
ap.add_argument("--out", default=str(ROOT / "dashboard" / "Hospital_Readmission_Dashboard.xlsx"))
ap.add_argument("--cache", default=None)
ap.add_argument("--shot", action="store_true")
ap.add_argument("--preset", default="")
args = ap.parse_args()

# --------------------------------------------------------------------------------------
# Data
# --------------------------------------------------------------------------------------
df = pd.read_csv(ROOT / "data" / "processed" / "HA_Data_clean.csv")
N = len(df)
LAST = N + 1  # last Excel row of the Data sheet (row 1 = header)

DATA_COLS = [  # (column in csv, header in Excel Data sheet, defined name)
    ("encounter_id", "encounter_id", None),
    ("patient_id", "patient_id", None),
    ("race", "race", "d_Race"),
    ("gender", "gender", "d_Gender"),
    ("age_group", "age_group", "d_Age"),
    ("medical_specialty", "medical_specialty", "d_Spec"),
    ("time_in_hospital", "time_in_hospital", "d_LOS"),
    ("num_lab_procedures", "num_lab_procedures", "d_Labs"),
    ("num_procedures", "num_procedures", "d_Procs"),
    ("num_medications", "num_medications", "d_Meds"),
    ("number_outpatient", "number_outpatient", "d_Outp"),
    ("number_emergency", "number_emergency", "d_ER"),
    ("number_inpatient", "number_inpatient", "d_Inp"),
    ("number_diagnoses", "number_diagnoses", "d_Dx"),
    ("medication_change", "medication_change", "d_Chg"),
    ("diabetesMed", "diabetes_med", "d_Diab"),
    ("readmitted", "readmitted", "d_Read"),
    ("prior_inpatient_band", "prior_inpatient_band", "d_InpB"),
    ("prior_er_band", "prior_er_band", "d_ErB"),
    ("comorbidity_band", "comorbidity_band", "d_DxB"),
    ("medication_band", "medication_band", "d_MedB"),
    ("lab_band", "lab_band", "d_LabB"),
]

AGE_LABELS = [f"{a}-{a + 9} yrs" for a in range(0, 100, 10)]
RACE_ORDER = ["Caucasian", "AfricanAmerican", "Hispanic", "Other", "Asian", "Unknown"]
INP_LABELS = ["0 visits", "1 visit", "2 visits", "3 visits", "4+ visits"]
ER_LABELS = ["0 visits", "1 visit", "2 visits", "3+ visits"]
DX_LABELS = ["1-4 dx", "5-6 dx", "7-8 dx", "9+ dx"]
MED_LABELS = ["1-10 meds", "11-15 meds", "16-20 meds", "21-30 meds", "31+ meds"]

known = df[df.medical_specialty != "Unknown"]
top_spec = known.medical_specialty.value_counts().head(10).index.tolist()
# fixed display order: highest full-data readmission rate first
SPEC_ORDER = (
    known[known.medical_specialty.isin(top_spec)]
    .groupby("medical_specialty").readmitted.mean().sort_values(ascending=False).index.tolist()
)

# --------------------------------------------------------------------------------------
# Optional cached values (from a LibreOffice-recalculated copy)
# --------------------------------------------------------------------------------------
CACHE = {}
if args.cache:
    from openpyxl import load_workbook
    cwb = load_workbook(args.cache, data_only=True, read_only=True)
    for sn in ("Dashboard", "Calc"):
        for row in cwb[sn].iter_rows():
            for c in row:
                if c.value is not None:
                    CACHE[(sn, c.coordinate)] = c.value
    cwb.close()

# --------------------------------------------------------------------------------------
# Workbook + palette + formats
# --------------------------------------------------------------------------------------
wb = xlsxwriter.Workbook(args.out, {"default_format_properties": {"font_name": "Arial", "font_size": 10}})
wb.set_calc_mode("auto")

NAVY, TEAL, AMBER, RED, GREEN = "#14284B", "#0E8F8B", "#F2A541", "#C0392B", "#1E8449"
GREY_TXT, BG, LINE, SLATE = "#5B6B7F", "#EEF1F5", "#D5DCE5", "#8FA3B8"

_fc = {}


def F(**kw):
    kw.setdefault("font_name", "Arial")
    key = tuple(sorted(kw.items()))
    if key not in _fc:
        _fc[key] = wb.add_format(kw)
    return _fc[key]


def W(ws, a1, formula, fmt=None):
    """write a formula, storing the cached value when we have one"""
    v = CACHE.get((ws.get_name(), a1), 0)
    ws.write_formula(a1, formula, fmt, "" if v is None else v)


ws_dash = wb.add_worksheet("Dashboard")
ws_about = wb.add_worksheet("About")
ws_calc = wb.add_worksheet("Calc")
ws_data = wb.add_worksheet("Data")

# --------------------------------------------------------------------------------------
# DATA sheet
# --------------------------------------------------------------------------------------
hdr = F(bold=True, font_color="#FFFFFF", bg_color=NAVY, align="center", valign="vcenter", border=1, border_color=NAVY)
for j, (_, h, _n) in enumerate(DATA_COLS):
    ws_data.write(0, j, h, hdr)
values = df[[c for c, _, _ in DATA_COLS]].astype(object).values.tolist()
for i, row in enumerate(values, start=1):
    ws_data.write_row(i, 0, row)
ws_data.freeze_panes(1, 0)
ws_data.autofilter(0, 0, N, len(DATA_COLS) - 1)
ws_data.set_column(0, 1, 13)
ws_data.set_column(2, 5, 17)
ws_data.set_column(5, 5, 26)
ws_data.set_column(6, 21, 15)
ws_data.set_row(0, 30)
ws_data.set_tab_color("#7F8C8D")

for j, (_, _h, name) in enumerate(DATA_COLS):
    if name:
        col = xlsxwriter.utility.xl_col_to_name(j)
        wb.define_name(name, f"=Data!${col}$2:${col}${LAST}")

# --------------------------------------------------------------------------------------
# CALC sheet
# --------------------------------------------------------------------------------------
FILTERS = {  # key -> (data range name, criteria-cell name, label, Dashboard cell, options)
    "Gender": ("d_Gender", "c_Gender", "Gender", "B6", ["All", "Female", "Male"]),
    "Race": ("d_Race", "c_Race", "Race", "F6", ["All"] + RACE_ORDER),
    "Age": ("d_Age", "c_Age", "Age group", "J6", ["All"] + AGE_LABELS),
    "Diab": ("d_Diab", "c_Diab", "Diabetes medication prescribed", "N6", ["All", "Yes", "No"]),
    "Chg": ("d_Chg", "c_Chg", "Diabetic medication changed", "R6", ["All", "Changed", "No Change"]),
}


def crit(exclude=(), extra=()):
    parts = [f"{r},{c}" for k, (r, c, *_rest) in FILTERS.items() if k not in exclude]
    parts += [f"{r},{v}" for r, v in extra]
    return ",".join(parts)


preset = {}
for kv in filter(None, args.preset.split(",")):
    k, v = kv.split("=")
    preset[k.strip()] = v.strip()

c_title = F(bold=True, font_size=14, font_color=NAVY)
c_note = F(italic=True, font_color=GREY_TXT)
c_sec = F(bold=True, font_color="#FFFFFF", bg_color=TEAL)
c_th = F(bold=True, bg_color="#DCE6F1", border=1, border_color=LINE, align="center", text_wrap=True)
c_lbl = F(border=1, border_color=LINE)
c_int = F(border=1, border_color=LINE, num_format="#,##0")
c_pct = F(border=1, border_color=LINE, num_format="0.0%")
c_dec = F(border=1, border_color=LINE, num_format="0.00")
c_txt = F(border=1, border_color=LINE, text_wrap=True, valign="top")
c_input = F(border=1, border_color=LINE, font_color="#0000FF", bg_color="#FFFF00", bold=True)

ws_calc.set_column("A:A", 44)
ws_calc.set_column("B:H", 15)
ws_calc.set_tab_color("#7F8C8D")
ws_calc.write("A1", "Calculation sheet - every KPI and chart on the Dashboard reads from here", c_title)
ws_calc.write("A2", "All values are live formulas over the Data sheet. Only the yellow cell (B11) is meant to be edited.", c_note)

# filter criteria ------------------------------------------------------------------
ws_calc.merge_range("A3:C3", "FILTER CRITERIA  (\"All\" becomes the wildcard *)", c_sec)
for i, (k, (rng, cname, label, dcell, _opts)) in enumerate(FILTERS.items()):
    r = 4 + i
    ws_calc.write(f"A{r}", label, c_lbl)
    W(ws_calc, f"B{r}", f"=Dashboard!${dcell[0]}${dcell[1:]}", c_lbl)
    W(ws_calc, f"C{r}", f'=IF(B{r}="All","*",B{r})', c_lbl)
    wb.define_name(cname, f"=Calc!$C${r}")

ws_calc.merge_range("A10:C10", "ASSUMPTION", c_sec)
ws_calc.write("A11", "Minimum encounters for a group to count in 'highest / lowest' insights", c_lbl)
ws_calc.write("B11", 100, c_input)
ws_calc.write("C11", "Blue on yellow = input", c_note)
wb.define_name("minN", "=Calc!$B$11")

# KPI block --------------------------------------------------------------------------
ws_calc.merge_range("A13:D13", "KPIs", c_sec)
for j, h in enumerate(["Metric", "Selected filters", "All data (baseline)", "Difference / share"]):
    ws_calc.write(13, j, h, c_th)
K = crit()
kp = {  # row -> (label, filtered formula, baseline formula, delta formula, format)
    15: ("Encounters", f"=COUNTIFS({K})", "=COUNT(d_Read)", "=IF(C15=0,0,B15/C15)", c_int),
    16: ("Readmitted within 30 days", f"=COUNTIFS({K},d_Read,1)", "=COUNTIF(d_Read,1)", "=IF(C16=0,0,B16/C16)", c_int),
    17: ("Readmission rate", "=IF(B15=0,0,B16/B15)", "=IF(C15=0,0,C16/C15)", "=B17-C17", c_pct),
    18: ("Average length of stay (days)", f"=IF(B15=0,0,SUMIFS(d_LOS,{K})/B15)", "=AVERAGE(d_LOS)", "=B18-C18", c_dec),
    19: ("Average medications per encounter", f"=IF(B15=0,0,SUMIFS(d_Meds,{K})/B15)", "=AVERAGE(d_Meds)", "=B19-C19", c_dec),
    20: ("Share with 1+ inpatient stay in prior year", f'=IF(B15=0,0,COUNTIFS({K},d_InpB,"<>0 visits")/B15)',
         '=COUNTIF(d_InpB,"<>0 visits")/C15', "=B20-C20", c_pct),
}
for r, (lab, f1, f2, f3, fm) in kp.items():
    ws_calc.write(f"A{r}", lab, c_lbl)
    W(ws_calc, f"B{r}", f1, fm)
    W(ws_calc, f"C{r}", f2, fm)
    W(ws_calc, f"D{r}", f3, c_pct if r in (17, 20) else (c_dec if r in (18, 19) else c_pct))
ws_calc.write("A21", "Column D: share of all data for rows 15-16; percentage-point / unit difference vs baseline for rows 17-20.", c_note)

# generic table ------------------------------------------------------------------------
TAB = {}


def table(key, r0, title, rows, default_excl=()):
    """rows: list of dicts(label, rng, lit=None, excl=None). r0 = 1-indexed title row."""
    ws_calc.merge_range(f"A{r0}:H{r0}", title, c_sec)
    heads = ["Category", "Encounters", "Readmitted", "Readmit rate", "Avg LOS (days)",
             "Rate (hi helper)", "Rate (lo helper)", "LOS (hi helper)"]
    for j, h in enumerate(heads):
        ws_calc.write(r0, j, h, c_th)
    first = r0 + 2
    for i, row in enumerate(rows):
        rr = first + i
        excl = row.get("excl", default_excl)
        expr = f"$A{rr}" if row.get("lit") is None else f'"{row["lit"]}"'
        base = crit(excl, [(row["rng"], expr)])
        ws_calc.write(f"A{rr}", row["label"], c_lbl)
        W(ws_calc, f"B{rr}", f"=COUNTIFS({base})", c_int)
        W(ws_calc, f"C{rr}", f"=COUNTIFS({base},d_Read,1)", c_int)
        W(ws_calc, f"D{rr}", f"=IF(B{rr}=0,0,C{rr}/B{rr})", c_pct)
        W(ws_calc, f"E{rr}", f"=IF(B{rr}=0,0,SUMIFS(d_LOS,{base})/B{rr})", c_dec)
        W(ws_calc, f"F{rr}", f"=IF(B{rr}>=minN,D{rr},-1)", c_pct)
        W(ws_calc, f"G{rr}", f"=IF(B{rr}>=minN,D{rr},2)", c_pct)
        W(ws_calc, f"H{rr}", f"=IF(B{rr}>=minN,E{rr},-1)", c_dec)
    last = first + len(rows) - 1
    TAB[key] = dict(first=first, last=last)
    return last + 2


def simple(label_list, rng):
    return [dict(label=l, rng=rng) for l in label_list]


r = 23
r = table("age", r, "Readmission by age group (age filter ignored so groups stay comparable)",
          simple(AGE_LABELS, "d_Age"), default_excl=("Age",))
r = table("inp", r, "Readmission by prior inpatient visits (previous 12 months)", simple(INP_LABELS, "d_InpB"))
r = table("er", r, "Readmission by prior emergency visits (previous 12 months)", simple(ER_LABELS, "d_ErB"))
r = table("spec", r, "Top-10 known medical specialties (ordered by full-data readmission rate)", simple(SPEC_ORDER, "d_Spec"))
r = table("race", r, "Readmission by race (race filter ignored so groups stay comparable)",
          simple(RACE_ORDER, "d_Race"), default_excl=("Race",))
r = table("dx", r, "Comorbidity: number of diagnoses entered", simple(DX_LABELS, "d_DxB"))
r = table("med", r, "Number of distinct medications prescribed", simple(MED_LABELS, "d_MedB"))
r = table("mm", r, "Medication management (own filter ignored in each row)", [
    dict(label="Diabetic meds changed", rng="d_Chg", lit="Changed", excl=("Chg",)),
    dict(label="Diabetic meds not changed", rng="d_Chg", lit="No Change", excl=("Chg",)),
    dict(label="On diabetic medication", rng="d_Diab", lit="Yes", excl=("Diab",)),
    dict(label="Not on diabetic medication", rng="d_Diab", lit="No", excl=("Diab",)),
])


def rng(key, col):
    t = TAB[key]
    return f"${col}${t['first']}:${col}${t['last']}"


# insight text -------------------------------------------------------------------------
ws_calc.merge_range(f"A{r}:H{r}", "INSIGHT TEXT (shown on the Dashboard)", c_sec)
ins_rows = []
mm, inp = TAB["mm"], TAB["inp"]
insights = [
    # 1 selected group vs overall
    '=IF($B$15=0,"No encounters match the selected filters.","Selected group: "&TEXT($B$15,"#,##0")&" encounters with a "'
    '&TEXT($B$17,"0.0%")&" 30-day readmission rate"&IF(ABS($D$17)<0.0005," - the same as the overall rate."'
    '," - "&TEXT(ABS($D$17)*100,"0.0")&" pts "&IF($D$17>0,"above","below")&" the overall "&TEXT($C$17,"0.0%")&"."))',
    # 2 age
    f'=IF(MAX({rng("age","F")})<0,"Not enough data for an age comparison.","Highest-risk age band: "'
    f'&INDEX({rng("age","A")},MATCH(MAX({rng("age","F")}),{rng("age","F")},0))&" ("&TEXT(MAX({rng("age","F")}),"0.0%")'
    f'&"); lowest: "&INDEX({rng("age","A")},MATCH(MIN({rng("age","G")}),{rng("age","G")},0))&" ("'
    f'&TEXT(MIN({rng("age","G")}),"0.0%")&")."&" Groups under "&minN&" encounters are ignored.")',
    # 3 prior inpatient
    f'=IF(OR($B${inp["last"]}<minN,$D${inp["first"]}=0),"Not enough data for the prior-inpatient comparison.",'
    f'"Prior inpatient stays: "&TEXT($D${inp["last"]},"0.0%")&" readmitted with 4+ prior stays vs "'
    f'&TEXT($D${inp["first"]},"0.0%")&" with none ("&TEXT($D${inp["last"]}/$D${inp["first"]},"0.0")&"x higher).")',
    # 4 specialty
    f'=IF(MAX({rng("spec","F")})<0,"Not enough data for a specialty comparison.","Highest readmission rate: "'
    f'&INDEX({rng("spec","A")},MATCH(MAX({rng("spec","F")}),{rng("spec","F")},0))&" ("&TEXT(MAX({rng("spec","F")}),"0.0%")'
    f'&"); longest average stay: "&INDEX({rng("spec","A")},MATCH(MAX({rng("spec","H")}),{rng("spec","H")},0))&" ("'
    f'&TEXT(MAX({rng("spec","H")}),"0.0")&" days).")',
    # 5 medication change
    f'=IF(OR($B${mm["first"]}<minN,$B${mm["first"]+1}<minN),"Not enough data for the medication-change comparison.",'
    f'"Diabetic medication changed during the stay: "&TEXT($D${mm["first"]},"0.0%")&" readmitted vs "'
    f'&TEXT($D${mm["first"]+1},"0.0%")&" when unchanged ("&TEXT(($D${mm["first"]}-$D${mm["first"]+1})*100,"+0.0;-0.0")&" pts).")',
]
for i, f in enumerate(insights):
    rr = r + 1 + i
    W(ws_calc, f"A{rr}", f, F(text_wrap=False))
    ins_rows.append(rr)

# --------------------------------------------------------------------------------------
# DASHBOARD sheet
# --------------------------------------------------------------------------------------
ws = ws_dash
ws.hide_gridlines(2)
ws.set_zoom(85)
ws.set_tab_color(TEAL)
bg = F(bg_color=BG)
ws.set_column("A:A", 2, bg)
ws.set_column("B:Y", 8.9, bg)
ws.set_column("Z:Z", 2, bg)
ws.set_column("AA:BZ", 8.9, bg)

# banner ---------------------------------------------------------------------------------
ws.set_row(0, 6, bg)
ws.set_row(1, 36)
ws.set_row(2, 20)
ws.merge_range("A2:Z2", "  Hospital Readmission Analytics", F(bold=True, font_size=22, font_color="#FFFFFF", bg_color=NAVY, valign="vcenter"))
ws.merge_range("A3:Z3", "", F(font_size=10, font_color="#C9D6E8", bg_color=NAVY, valign="vcenter"))
W(ws, "A3", '="  30-day readmission risk  |  "&TEXT(Calc!$C$15,"#,##0")&" unique encounters  |  Source: HA_Data.csv (de-duplicated)"',
  F(font_size=10, font_color="#C9D6E8", bg_color=NAVY, valign="vcenter"))
ws.set_row(3, 8, bg)

# filters ----------------------------------------------------------------------------------
lab_f = F(bold=True, font_size=8, font_color=GREY_TXT, bg_color=BG, valign="bottom")
box_f = F(bold=True, font_size=11, font_color=NAVY, bg_color="#FFFFFF", align="center", valign="vcenter",
          border=2, border_color=TEAL)
ws.set_row(4, 16)
ws.set_row(5, 26)
spans = {"B": "D", "F": "H", "J": "L", "N": "P", "R": "T"}
for k, (_r, _c, label, dcell, opts) in FILTERS.items():
    c0 = dcell[0]
    c1 = spans[c0]
    ws.merge_range(f"{c0}5:{c1}5", label.upper(), lab_f)
    ws.merge_range(f"{c0}6:{c1}6", preset.get(k, "All"), box_f)
    ws.data_validation(dcell, {
        "validate": "list", "source": opts,
        "input_title": label, "input_message": "Click the arrow and pick a value (or All).",
        "error_title": "Pick from the list", "error_message": "Please choose one of the values in the dropdown.",
    })
ws.merge_range("V5:Y6", "FILTERS: click a teal box, use the dropdown arrow, and every KPI, insight and chart updates.",
               F(italic=True, font_size=8, font_color=GREY_TXT, bg_color=BG, text_wrap=True, valign="vcenter"))
ws.set_row(6, 8, bg)

# KPI cards ----------------------------------------------------------------------------------
cards = [  # column letters, label, Calc row, number format, accent, sub formula, delta cell for colour (None = neutral)
    ("B", "E", "ENCOUNTERS", 15, "#,##0", NAVY, '=TEXT(Calc!$D$15,"0%")&" of all encounters"', None),
    ("F", "I", "READMITTED (30 DAYS)", 16, "#,##0", RED, '=TEXT(Calc!$D$16,"0%")&" of all readmissions"', None),
    ("J", "M", "READMISSION RATE", 17, "0.0%", RED,
     '=IF(ABS(Calc!$D$17)<0.0005,"same as overall",IF(Calc!$D$17>0,"▲ ","▼ ")&TEXT(ABS(Calc!$D$17)*100,"0.0")&" pts vs overall")', "Calc!$D$17"),
    ("N", "Q", "AVG LENGTH OF STAY", 18, '0.0 "days"', AMBER,
     '=IF(ABS(Calc!$D$18)<0.005,"same as overall",IF(Calc!$D$18>0,"▲ ","▼ ")&TEXT(ABS(Calc!$D$18),"0.00")&" days vs overall")', "Calc!$D$18"),
    ("R", "U", "AVG MEDICATIONS", 19, "0.0", TEAL,
     '=IF(ABS(Calc!$D$19)<0.005,"same as overall",IF(Calc!$D$19>0,"▲ ","▼ ")&TEXT(ABS(Calc!$D$19),"0.0")&" vs overall")', None),
    ("V", "Y", "PRIOR-INPATIENT SHARE", 20, "0.0%", NAVY,
     '=IF(ABS(Calc!$D$20)<0.0005,"same as overall",IF(Calc!$D$20>0,"▲ ","▼ ")&TEXT(ABS(Calc!$D$20)*100,"0.0")&" pts vs overall")', "Calc!$D$20"),
]
ws.set_row(7, 20)
ws.set_row(8, 22)
ws.set_row(9, 22)
ws.set_row(10, 18)
gap = dict(left=5, right=5, left_color=BG, right_color=BG)
for c0, c1, lab, crow, nf, accent, sub, dref in cards:
    ws.merge_range(f"{c0}8:{c1}8", lab, F(bold=True, font_size=8, font_color=GREY_TXT, bg_color="#FFFFFF", align="center",
                                           valign="vcenter", top=5, top_color=accent, **gap))
    vf = F(bold=True, font_size=24, font_color=NAVY, bg_color="#FFFFFF", align="center", valign="vcenter", num_format=nf, **gap)
    ws.merge_range(f"{c0}9:{c1}10", "", vf)
    W(ws, f"{c0}9", f"=Calc!$B${crow}", vf)
    sf = F(font_size=9, font_color=GREY_TXT, bg_color="#FFFFFF", align="center", valign="vcenter", bottom=5, bottom_color=BG, **gap)
    ws.merge_range(f"{c0}11:{c1}11", "", sf)
    W(ws, f"{c0}11", sub, sf)
    if dref:  # higher than overall = worse for rate / stay / prior-inpatient share
        ws.conditional_format(f"{c0}11", {"type": "formula", "criteria": f"={dref}>0.0005" if crow != 18 else f"={dref}>0.005",
                                          "format": wb.add_format({"font_color": RED, "bold": True})})
        ws.conditional_format(f"{c0}11", {"type": "formula", "criteria": f"={dref}<-0.0005" if crow != 18 else f"={dref}<-0.005",
                                          "format": wb.add_format({"font_color": GREEN, "bold": True})})
ws.set_row(11, 8, bg)

# key insights -------------------------------------------------------------------------------
sec = F(bold=True, font_size=10, font_color="#FFFFFF", bg_color=NAVY, valign="vcenter")
ws.set_row(12, 20)
ws.merge_range("B13:Y13", "  KEY INSIGHTS  (text updates with the filters)", sec)
ins_f = F(font_size=10, font_color="#1F2D3D", bg_color="#FFFFFF", valign="vcenter", indent=1,
          bottom=1, bottom_color=LINE, left=5, left_color=TEAL)
for i, cr in enumerate(ins_rows):
    row = 14 + i
    ws.set_row(row - 1, 21)
    ws.merge_range(f"B{row}:Y{row}", "", ins_f)
    W(ws, f"B{row}", f"=Calc!$A${cr}", ins_f)
ws.set_row(18, 8, bg)

# chart helpers ------------------------------------------------------------------------------
AXF = {"name": "Arial", "size": 9, "color": "#44546A"}


def mk(kind, title, w=528, h=272, legend=False):
    ch = wb.add_chart(kind)
    ch.set_title({"name": title, "name_font": {"name": "Arial", "size": 11, "bold": True, "color": NAVY}, "overlay": False})
    ch.set_legend({"position": "bottom", "font": AXF} if legend else {"none": True})
    ch.set_chartarea({"border": {"color": LINE}, "fill": {"color": "#FFFFFF"}})
    ch.set_plotarea({"fill": {"none": True}})
    ch.set_size({"width": w, "height": h})
    return ch


def cat_axis(ch, **kw):
    ch.set_x_axis({"num_font": AXF, "line": {"color": "#BFC8D4"}, "major_tick_mark": "none", **kw})


def val_axis(ch, fmt="0%", **kw):
    ch.set_y_axis({"num_format": fmt, "num_font": AXF, "line": {"none": True}, "min": 0,
                   "major_gridlines": {"visible": True, "line": {"color": "#E6EAF0", "width": 0.75}}, **kw})


def dl(fmt, pos="outside_end"):
    return {"value": True, "num_format": fmt, "position": pos, "font": {"name": "Arial", "size": 8, "color": "#333333"}}


def ref(key, col):
    t = TAB[key]
    return f"=Calc!${col}${t['first']}:${col}${t['last']}"


def column(key, title, col="D", fmt="0%", dfmt="0.0%", color=TEAL, points=None, name="Readmission rate"):
    ch = mk({"type": "column"}, title)
    s = {"name": name, "categories": ref(key, "A"), "values": ref(key, col), "fill": {"color": color},
         "gap": 55, "data_labels": dl(dfmt)}
    if points:
        s["points"] = [{"fill": {"color": p}} for p in points]
    ch.add_series(s)
    cat_axis(ch)
    val_axis(ch, fmt)
    return ch


def hbar(key, title, col, fmt, color):
    ch = mk({"type": "bar"}, title)
    ch.add_series({"name": title, "categories": ref(key, "A"), "values": ref(key, col), "fill": {"color": color},
                   "gap": 45, "data_labels": dl(fmt)})
    # NB: in xlsxwriter bar charts the axes are swapped - set_y_axis() is the vertical CATEGORY axis,
    # set_x_axis() is the horizontal VALUE axis.
    ch.set_y_axis({"reverse": True, "num_font": AXF, "line": {"color": "#BFC8D4"}, "major_tick_mark": "none"})
    ch.set_x_axis({"visible": False, "min": 0, "major_gridlines": {"visible": False}})
    return ch


# chart grid -----------------------------------------------------------------------------------
COLS = [1, 9, 17]  # B, J, R


def section(row1, text):
    ws.set_row(row1 - 1, 22)
    ws.merge_range(f"B{row1}:Y{row1}", "  " + text, sec)


def place(chart, row1, slot):
    ws.insert_chart(row1 - 1, COLS[slot], chart, {"x_offset": 4, "y_offset": 4, "object_position": 2})


# row A ------------------------------------------------------------------------------------------
section(20, "1  |  WHO IS BEING READMITTED?  Age and prior utilisation")
place(column("age", "Readmission rate by age group"), 21, 0)
place(column("inp", "Readmission rate by prior inpatient visits", color=RED), 21, 1)
place(column("er", "Readmission rate by prior emergency visits", color=AMBER), 21, 2)

# row B ------------------------------------------------------------------------------------------
section(36, "2  |  WHERE AND FOR WHOM?  Specialty and race")
place(hbar("spec", "Readmission rate by specialty (top 10 known)", "D", "0.0%", TEAL), 37, 0)
place(hbar("spec", "Average length of stay by specialty (days)", "E", "0.0", NAVY), 37, 1)
place(column("race", "Readmission rate by race", color=SLATE), 37, 2)

# row C ------------------------------------------------------------------------------------------
section(52, "3  |  CLINICAL COMPLEXITY AND MEDICATION MANAGEMENT")
combo = mk({"type": "column"}, "Comorbidity: avg stay (bars) and readmission rate (line)", legend=True)
combo.add_series({"name": "Avg length of stay (days)", "categories": ref("dx", "A"), "values": ref("dx", "E"),
                  "fill": {"color": AMBER}, "gap": 60})
cat_axis(combo)
val_axis(combo, "0.0", name="days", name_font={"name": "Arial", "size": 8, "color": GREY_TXT})
ln = wb.add_chart({"type": "line"})
ln.add_series({"name": "Readmission rate", "categories": ref("dx", "A"), "values": ref("dx", "D"), "y2_axis": True,
               "line": {"color": NAVY, "width": 2.25}, "marker": {"type": "circle", "size": 7, "fill": {"color": NAVY}, "border": {"color": "#FFFFFF"}},
               "data_labels": dl("0.0%", "above")})
ln.set_y2_axis({"num_format": "0%", "num_font": AXF, "min": 0, "line": {"none": True}, "major_gridlines": {"visible": False}})
combo.combine(ln)
place(combo, 53, 0)
place(column("med", "Average length of stay by number of medications", col="E", fmt="0.0", dfmt="0.0", color=TEAL,
             name="Avg length of stay (days)"), 53, 1)
place(column("mm", "Readmission rate: diabetic medication use and changes", points=[TEAL, SLATE, TEAL, SLATE]), 53, 2)

# footnotes ---------------------------------------------------------------------------------------
ws.set_row(67, 8, bg)
note_f = F(font_size=8, font_color=GREY_TXT, bg_color=BG, text_wrap=True, valign="top")
ws.set_row(68, 30)
ws.set_row(69, 30)
ws.merge_range("B69:Y69",
               "Notes: (1) 17,676 exact duplicate rows were removed from the 66,587 raw rows before analysis.  (2) Readmission rate = encounters flagged "
               "readmitted (<30 days) / encounters.  (3) Age and Race charts ignore their own filter so the groups stay comparable; all other charts follow every filter.",
               note_f)
ws.merge_range("B70:Y70",
               "(4) Specialty chart shows the 10 largest known specialties (about half of encounters have no specialty recorded).  (5) Groups under 100 encounters "
               "are ignored in the highest / lowest insights.  (6) Differences shown are associations, not proof of cause.  (7) The file has no dates, so no trend view is possible.",
               note_f)

ws.set_landscape()
ws.set_paper(8)
ws.fit_to_pages(1, 1)
ws.print_area("A1:Z71")
ws.set_margins(0.3, 0.3, 0.3, 0.3)
ws.activate()

# --------------------------------------------------------------------------------------
# ABOUT sheet
# --------------------------------------------------------------------------------------
wa = ws_about
wa.hide_gridlines(2)
wa.set_column("A:A", 3)
wa.set_column("B:B", 30)
wa.set_column("C:C", 105)
wa.set_tab_color(NAVY)
h1 = F(bold=True, font_size=18, font_color=NAVY)
h2 = F(bold=True, font_size=11, font_color="#FFFFFF", bg_color=TEAL, valign="vcenter")
k = F(bold=True, valign="top", text_wrap=True, bottom=1, bottom_color=LINE)
v = F(valign="top", text_wrap=True, bottom=1, bottom_color=LINE)
wa.write("B1", "About this dashboard", h1)
rows = [
    ("h", "PURPOSE"),
    ("Business question", "A hospital administration team wants to understand which patients are readmitted within 30 days, so follow-up "
     "and resources can be targeted. This workbook turns the encounter-level data into an interactive dashboard."),
    ("Audience", "Hospital board / C-suite (headline KPIs), department heads (specialty view), clinical quality teams (risk drivers)."),
    ("h", "HOW TO USE"),
    ("1. Pick filters", "Go to the Dashboard sheet and use the five teal dropdown boxes (Gender, Race, Age group, Diabetes medication, Diabetic medication change)."),
    ("2. Read top to bottom", "KPI cards -> Key insights (text rewrites itself) -> Section 1 (who) -> Section 2 (where / for whom) -> Section 3 (clinical complexity)."),
    ("3. Reset", "Set every filter back to All."),
    ("4. Excel note", "Formulas recalculate automatically. With filters set to All the 20+ COUNTIFS run over 48,911 rows - allow a second after each change."),
    ("h", "SHEETS"),
    ("Dashboard", "The presentation layer: filters, KPI cards, insights, 9 charts."),
    ("Calc", "All formulas (COUNTIFS / SUMIFS) that feed the Dashboard. One small table per chart. Yellow cell B11 = minimum group size for insights."),
    ("Data", "Cleaned encounter-level data (48,911 rows) with derived band columns. Filters/sorting here do not affect the Dashboard."),
    ("h", "DEFINITIONS"),
    ("Readmission rate", "Share of encounters with readmitted = 1 (readmitted within 30 days in the source file)."),
    ("Length of stay", "time_in_hospital, in days."),
    ("Prior visits", "number_inpatient / number_emergency = visits in the 12 months before the encounter."),
    ("Comorbidity", "number_diagnoses used as a simple comorbidity indicator (bands: 1-4, 5-6, 7-8, 9+)."),
    ("h", "ASSUMPTIONS AND DATA NOTES"),
    ("De-duplication", "17,676 exact duplicate rows removed (66,587 -> 48,911). See reports/data_quality_log.md."),
    ("Unknown values", "'?' in race and medical_specialty recoded to Unknown. Unknown rows stay in totals; the specialty chart lists only known specialties."),
    ("Bands", "Age (10-year groups), prior visits, diagnoses, medications and lab-procedure bands were created in scripts/01_clean_data.py and stored as text columns in Data."),
    ("Minimum group size", "100 encounters (Calc!B11) - smaller groups are excluded when picking the 'highest' or 'lowest' group in the insights."),
    ("Limits", "No dates (no trend analysis), no cost or discharge fields, weight is ~97% missing. The 46% readmission rate is far above real-world diabetes "
     "figures (~10-12%), so treat this as a training dataset."),
    ("Not causal", "Every difference is an association in this dataset; it does not prove that a factor causes readmission."),
    ("h", "SOURCE"),
    ("Data", "HA_Data.csv - hospital administration data from the case study (Kaggle: shivavashishtha/hospital-administration-data)."),
]
r = 3
for a, *b in rows:
    if a == "h":
        wa.merge_range(f"B{r}:C{r}", "  " + b[0], h2)
        wa.set_row(r - 1, 20)
    else:
        wa.write(f"B{r}", a, k)
        wa.write(f"C{r}", b[0], v)
        wa.set_row(r - 1, 30 if len(b[0]) > 100 else 18)
    r += 1

if args.shot:
    ws_about.hide()
    ws_calc.hide()
    ws_data.hide()

wb.close()
print("wrote", args.out)
