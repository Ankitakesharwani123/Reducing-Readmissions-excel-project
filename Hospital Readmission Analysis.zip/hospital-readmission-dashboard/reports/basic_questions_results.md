# Basic-level questions - results

Base: **48,911** unique encounters, overall 30-day readmission rate **46.2%**.

## Q1. Readmission rate by age group

| age_group   |   encounters |   readmit_rate |
|:------------|-------------:|---------------:|
| 0-9 yrs     |           77 |          0.195 |
| 10-19 yrs   |          313 |          0.409 |
| 20-29 yrs   |          817 |          0.431 |
| 30-39 yrs   |         1766 |          0.419 |
| 40-49 yrs   |         4619 |          0.447 |
| 50-59 yrs   |         8421 |          0.448 |
| 60-69 yrs   |        10964 |          0.467 |
| 70-79 yrs   |        12478 |          0.482 |
| 80-89 yrs   |         8103 |          0.478 |
| 90-99 yrs   |         1353 |          0.387 |

Highest: **70-79 yrs** (48.2%); lowest: **0-9 yrs** (19.5%, only 77 encounters). Rates climb gradually from about 42% (30s) to about 48% (70s-80s); the 90s dip and the under-10 group are small samples.

## Q2. Average length of stay by specialty (known specialties with 100+ encounters)

| medical_specialty                 |   encounters |   avg_los |   readmit_rate |
|:----------------------------------|-------------:|----------:|---------------:|
| PhysicalMedicineandRehabilitation |          198 |     9.035 |          0.414 |
| Psychiatry                        |          432 |     6.694 |          0.426 |
| Surgery-Cardiovascular/Thoracic   |          304 |     6.043 |          0.247 |
| Pulmonology                       |          414 |     5.237 |          0.486 |
| Oncology                          |          167 |     5.162 |          0.503 |
| Cardiology                        |         2551 |     3.611 |          0.435 |
| Pediatrics                        |          116 |     3.483 |          0.431 |
| Radiologist                       |          570 |     3.461 |          0.439 |
| Urology                           |          329 |     3.222 |          0.374 |
| ObstetricsandGynecology           |          307 |     3.117 |          0.238 |

Longest: **PhysicalMedicineandRehabilitation** (9.0 days). Shortest: **ObstetricsandGynecology** (3.1 days). 49% of encounters have no specialty recorded.

## Q3. Prior emergency visits vs readmission

Pearson r = **0.109** (p = 1.5e-128, n = 48,911)

| prior_er_band   |   encounters |   readmit_rate |
|:----------------|-------------:|---------------:|
| 0 visits        |        43333 |          0.440 |
| 1 visit         |         3786 |          0.591 |
| 2 visits        |          951 |          0.679 |
| 3+ visits       |          841 |          0.790 |

Weak linear correlation, but the banded view shows a clear step-up: 3+ prior ER visits is 1.8x the rate of 0 visits.

## Q4. Share of diabetic patients readmitted within 30 days

- Using `diabetesMed = Yes`: **47.9%** of 37,640 encounters (vs 40.5% for `No`).
- Using ICD-9 codes starting `250` in diag_1..diag_4: **45.2%** of 18,315 encounters.

## Q5. Diabetic medication change vs readmission

| medication_change   |   encounters |   readmit_rate |
|:--------------------|-------------:|---------------:|
| Changed             |        22547 |          0.487 |
| No Change           |        26364 |          0.441 |

Chi-square = 102.0, p = 5.5e-24 -> difference is statistically significant (+4.6 pts when the regimen was changed). Association only: patients whose medication is changed may already be sicker.

## Q6. Lab procedures vs readmission

Pearson r = **0.037** (p = 2.6e-16, n = 48,911)

| lab_band   |   encounters |   readmit_rate |
|:-----------|-------------:|---------------:|
| 0-20 labs  |         6958 |          0.428 |
| 21-40 labs |        13390 |          0.447 |
| 41-60 labs |        19214 |          0.472 |
| 61-80 labs |         8430 |          0.494 |
| 81+ labs   |          919 |          0.448 |

Very weak relationship (rate rises from 42.8% to 49.4% up to 80 labs, then falls in a tiny group).

## Q7. Readmission rate by race and gender (2 rows with unknown gender excluded)

| race            |   Female |   Male |
|:----------------|---------:|-------:|
| AfricanAmerican |    0.468 |  0.451 |
| Asian           |    0.403 |  0.338 |
| Caucasian       |    0.476 |  0.463 |
| Hispanic        |    0.395 |  0.431 |
| Other           |    0.409 |  0.404 |
| Unknown         |    0.321 |  0.310 |

Encounters:

| race            |   Female |   Male |
|:----------------|---------:|-------:|
| AfricanAmerican |     5541 |   3595 |
| Asian           |      149 |    151 |
| Caucasian       |    19229 |  17408 |
| Hispanic        |      534 |    436 |
| Other           |      379 |    374 |
| Unknown         |      546 |    567 |

Overall: female 46.8% vs male 45.5%. Caucasian (47.0%) and African-American (46.0%) patients are highest; Asian, Hispanic, Other and Unknown have small samples (300-1,100 encounters). Gaps may reflect how data was recorded rather than differences in care - investigate before acting.

## Q8. Weight categories vs readmission

`weight` is recorded for only **3.2%** of encounters (1,557 rows) - too sparse for reliable conclusions.

| weight    |   encounters |   readmit_rate |
|:----------|-------------:|---------------:|
| >200      |            2 |          1.000 |
| [0-25)    |           21 |          0.810 |
| [100-125) |          293 |          0.577 |
| [125-150) |           76 |          0.539 |
| [150-175) |           15 |          0.333 |
| [175-200) |            6 |          0.500 |
| [25-50)   |           44 |          0.591 |
| [50-75)   |          442 |          0.536 |
| [75-100)  |          658 |          0.602 |

## Q9. Number of medications vs length of stay

Pearson r = **0.465**; each extra medication is associated with ~**0.17 extra days** of stay.

| medication_band   |   encounters |   avg_los |
|:------------------|-------------:|----------:|
| 1-10 meds         |        12428 |     2.890 |
| 11-15 meds        |        14044 |     3.830 |
| 16-20 meds        |        10989 |     4.708 |
| 21-30 meds        |         8918 |     6.008 |
| 31+ meds          |         2532 |     8.019 |

## Q10. Prior outpatient visits vs readmission

Pearson r = **0.083** (p = 1.4e-75, n = 48,911)

| band   |   encounters |   readmit_rate |
|:-------|-------------:|---------------:|
| 0      |        40785 |          0.438 |
| 1      |         4150 |          0.576 |
| 2      |         1750 |          0.602 |
| 3+     |         2226 |          0.589 |

Any prior outpatient visit is associated with a higher rate (~58-60% vs ~44% with none), but there is no further gradient beyond 1 visit.

## Bonus (medium Q2). Comorbidity (number of diagnoses)

| comorbidity_band   |   encounters |   avg_los |   readmit_rate |
|:-------------------|-------------:|----------:|---------------:|
| 1-4 dx             |         4630 |     3.004 |          0.354 |
| 5-6 dx             |        10339 |     3.851 |          0.399 |
| 7-8 dx             |        10058 |     4.170 |          0.470 |
| 9+ dx              |        23884 |     5.011 |          0.507 |

## Bonus. Correlation of each numeric field with readmission

|                    |   pearson_r |
|:-------------------|------------:|
| number_inpatient   |       0.220 |
| number_diagnoses   |       0.113 |
| number_emergency   |       0.109 |
| number_outpatient  |       0.083 |
| time_in_hospital   |       0.056 |
| num_medications    |       0.050 |
| num_lab_procedures |       0.037 |
| num_procedures     |      -0.044 |

Prior inpatient visits is the strongest single signal, followed by prior ER visits and number of diagnoses.
