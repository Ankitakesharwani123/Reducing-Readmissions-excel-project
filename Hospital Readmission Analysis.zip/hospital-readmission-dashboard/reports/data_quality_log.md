# Data quality log

- Raw rows: **66,587**
- Exact duplicate rows removed: **17,676** (26.5%) -> **48,911** unique encounters remain
- Unique patients after de-duplication: **39,650**
- `encounter_id` is unique after de-duplication: **True**

## Missing / invalid values (after de-duplication)

| Column | Rows marked `?` | Share | Treatment |
|---|---|---|---|
| race | 1,114 | 2.3% | recoded to `Unknown` |
| weight | 47,354 | 96.8% | recoded to `Unknown` |
| medical_specialty | 23,983 | 49.0% | recoded to `Unknown` |
| gender | 2 | <0.01% | `Unknown/Invalid` recoded to `Unknown` |
| X1, X2 | 87,062 blank cells | - | left as-is (not used in the dashboard) |

## Things to know before interpreting results

- **Readmission rate is high**: 46.2% of encounters are flagged `readmitted = 1`. Public diabetes-readmission data usually shows ~10-12% for <30 days, so treat this file as a training/case-study dataset, not real hospital performance.
- **`weight` is 97% missing**, so weight-based analysis is not reliable.
- **`medical_specialty` is 49% unknown**; specialty charts only show known specialties.
- **No date column exists**, so the 'trend / seasonality' question in the case study cannot be answered with this file.
- No discharge-disposition, cost, or satisfaction fields exist, so those case-study questions are out of scope.
- `diag_5` is a continuous float, not a diagnosis code - it is not used.

## Derived columns added

`age_group`, `medication_change`, `prior_inpatient_band`, `prior_er_band`, `comorbidity_band`, `medication_band`, `lab_band`.
