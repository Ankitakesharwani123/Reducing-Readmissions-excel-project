# Case study brief - Reducing Readmissions

**Scenario.** You are a data analyst in a large hospital's administration department. Readmission rates have spiked, raising costs and raising quality-of-care concerns. Analyse admission data to find the patterns and factors associated with readmissions so that interventions can be targeted.

**Stakeholders.** Board / trustees (cost, quality, reputation), C-suite (capacity, margins), department heads (staffing, patient flow), physicians and nurses (care quality), payers and regulators (cost, compliance), patients and families (outcomes).

**Question set (basic / medium / advanced) and how this project covers it**

| Level | Question | Status | Where |
|---|---|---|---|
| Basic 1 | Readmission by age group | Done | Dashboard chart 1, report Q1 |
| Basic 2 | Length of stay by specialty | Done | Dashboard chart 5, report Q2 |
| Basic 3 | Emergency visits vs readmission | Done | Dashboard chart 3, report Q3 |
| Basic 4 | Share of diabetic patients readmitted | Done | Dashboard chart 9, report Q4 |
| Basic 5 | Medication change vs readmission (with significance test) | Done | Dashboard chart 9, report Q5 |
| Basic 6 | Lab procedures vs readmission | Done (report only) | report Q6 |
| Basic 7 | Race and gender | Done | Dashboard chart 6 + gender filter, report Q7 |
| Basic 8 | Weight categories | Data too sparse (97% missing) | report Q8 |
| Basic 9 | Number of medications vs length of stay | Done | Dashboard chart 8, report Q9 |
| Basic 10 | Outpatient visits vs readmission | Done (report only) | report Q10 |
| Medium 2 | Comorbidity (number of diagnoses) vs stay and readmission | Done | Dashboard chart 7, report bonus |
| Medium 1 | Trend / seasonality | Not possible - no date column | - |
| Medium 3 | Discharge disposition | Not possible - field not in file | - |
| Medium 10 | Patient satisfaction | Not possible - field not in file | - |
| Medium 4-9, Advanced 1-5 | Demographic-treatment tests, prescribing patterns, predictive model, segmentation, cost impact, social determinants, follow-up programme | Not covered (see "Next steps" in the README) | - |

**Deliverables asked for:** case study document, solution guide, additional resources. In this repo: this brief, `reports/basic_questions_results.md` (solution guide for the basic questions), and the Excel dashboard.

**Data source:** https://www.kaggle.com/datasets/shivavashishtha/hospital-administration-data/
