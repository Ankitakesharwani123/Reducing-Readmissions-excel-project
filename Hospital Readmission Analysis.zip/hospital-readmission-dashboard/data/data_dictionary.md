# Data dictionary

## Raw file - `data/raw/HA_Data.csv` (66,587 rows x 49 columns)

| Column | Description |
|---|---|
| index | Row index from the source file (identical for duplicated rows) |
| encounter_id, patient_id | Unique encounter / patient identifiers |
| race, gender, age | Demographics. `age` is a 10-year bracket such as `[70-80)` = 70-79. `?` marks missing |
| weight | Weight bracket - ~97% missing (`?`) |
| time_in_hospital | Length of stay, days |
| medical_specialty | Specialty of the admitting physician (`?` = missing) |
| num_lab_procedures | Lab tests performed during the stay |
| num_procedures | Procedures other than lab tests |
| num_medications | Distinct medications prescribed |
| number_outpatient / number_emergency / number_inpatient | Visits in the 12 months before the encounter |
| diag_1 ... diag_5 | Diagnosis codes (`diag_5` is numeric noise, not a code) |
| number_diagnoses | Number of diagnoses entered |
| X1 ... X25 | Lab-result / medication indicator columns (meaning not documented in the source) |
| change | `Ch` = diabetic medication changed, `No` = not changed |
| diabetesMed | Any diabetic medication prescribed (Yes / No) |
| readmitted | **Target.** 1 = readmitted within 30 days, 0 = not |

## Processed file - `data/processed/HA_Data_clean.csv` (48,911 rows x 56 columns)

Same columns as the raw file after **removing 17,676 exact duplicate rows** and recoding `?` -> `Unknown`, plus seven derived columns:

| Derived column | Definition |
|---|---|
| age_group | `[70-80)` -> `70-79 yrs` |
| medication_change | `Ch` -> `Changed`, `No` -> `No Change` |
| prior_inpatient_band | number_inpatient: `0 visits`, `1 visit`, `2 visits`, `3 visits`, `4+ visits` |
| prior_er_band | number_emergency: `0 visits`, `1 visit`, `2 visits`, `3+ visits` |
| comorbidity_band | number_diagnoses: `1-4 dx`, `5-6 dx`, `7-8 dx`, `9+ dx` |
| medication_band | num_medications: `1-10`, `11-15`, `16-20`, `21-30`, `31+ meds` |
| lab_band | num_lab_procedures: `0-20`, `21-40`, `41-60`, `61-80`, `81+ labs` |

Band labels are written so Excel cannot mistake them for numbers or dates (a label like `10-20` would be coerced by `COUNTIFS`).

## Excel `Data` sheet

22 columns (identifiers, demographics, utilisation, medication fields, the target and the derived bands) - the subset the dashboard needs. `diabetesMed` is renamed `diabetes_med`.
